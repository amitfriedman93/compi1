import os
import subprocess
import sys

if __name__ == "__main__":
    test_flag = 1
    if '-c' in sys.argv:
        if 'all' in sys.argv:
            sys.argv.append('a')
            sys.argv.append('b')
            sys.argv.append('l')
        if 'l' in sys.argv:
            print("Compile lex")
            subprocess.call("flex scanner.lex", shell=True)
            print("Finished")
        if 'a' in sys.argv:
            print("Compile Part A")
            subprocess.call("g++ -std=c++11 lex.yy.c part_a.cpp -o a.out", shell=True)
            print("Finished")
        if 'b' in sys.argv:
            print("Compile Part B")
            subprocess.call("g++ -std=c++11 lex.yy.c part_b.cpp -o b.out", shell=True)
            print("Finished")
    if '-no_t' in sys.argv:
        test_flag = 0
    if test_flag == 1:
        print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Compi1 tester   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        cwd = os.getcwd()
        part_a_path = os.path.join(os.getcwd(), "partA")
        part_b_path = os.path.join(os.getcwd(), "partB")
        part_a_test = [f for f in os.listdir(part_a_path) if (os.path.isfile(os.path.join(part_a_path, f)) and f.endswith(".in"))]
        part_b_test = [f for f in os.listdir(part_b_path) if (os.path.isfile(os.path.join(part_b_path, f)) and f.endswith(".in"))]
        print("")
	test_count = 1
        for test in part_a_test:
            print("************************ PART A TEST "+str(test_count)+" ************************")
            subprocess.call("./a.out < " + part_a_path + "/test_partA_" + str(test_count) + ".in > " + part_a_path + "/test_partA_out_" + str(test_count), shell=True)
            subprocess.call("diff " + part_a_path + "/test_partA_" + str(test_count) + ".out" + " " + part_a_path + "/test_partA_out_" + str(test_count), shell=True)
            test_count += 1
	print("")
        test_count = 1
        for test in part_b_test:
            print("************************ PART B TEST "+str(test_count)+" ************************")
            subprocess.call("./b.out < " + part_b_path + "/test_partB_"+str(test_count)+".in > " + part_b_path + "/test_partB_out_"+str(test_count), shell=True)
            subprocess.call("diff " + part_b_path + "/test_partB_" + str(test_count) + ".out"+" "+ part_b_path + "/test_partB_out_" + str(test_count),shell=True)
            test_count+=1